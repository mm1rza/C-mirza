Produced by : BlueLife � velociraptor
www.sordum.org

##########  Windows Update Blocker v1.8  ##################
Release date: Friday, 9 June 2023

1. [FIXED] - Windows update service not found! error. (Auto recreate it)
2. [FIXED] - Sometimes,the update service fails to start
3. [ ADDED ] - /R parameter to repair errors in the Update service.
4. [ ADDED ] - Setting to close specified processes from ini file during the process
5. [ ADDED ] - Windows update troubleshooter shortcut (under the Menu)
6. [ ADDED ] - New methods to prevent overcoming the block of the Windows update service
7. [ ADDED ] - Many updates in coding


##########  Windows Update Blocker v1.7  ##################
Release date: Friday, 28 January 2022

1. [FIXED] - Only 25 services can be restricted from the ini file
2. [ ADDED ] - The Task Scheduler section has been rewritten. (determined from ini file)
3. [ ADDED ] - Option to block Process (application) from ini file
4. [ ADDED ] - Some code Improvements


##########  Windows Update Blocker v1.6  ##################
Release date: October 19, 2020 Monday

1. [FIXED] - GUI Font and icons are too small
2. [ ADDED ] - Manual option for wuauserv in windows update enable process
3. [ ADDED ] - x64 bit version
4. [ ADDED ] - Some code Improvements

##########  Windows Update Blocker v1.5  ##################
Release date: September 3, 2019

1. [ FIXED ] - There is a Windows Update Status Icon in Windows 10 Taskbar Notification Area
2. [ ADDED ] - 250 ms wait time added to check tasks properly.If there is a problem Update blocking process will be repeated
3. [ ADDED ] - Some code improvements

##########  Windows Update Blocker v1.4  ##################
Release date: August 21, 2019

1. [ FIXED ] - Windows Update Blocker doesn't disable Update Orchestrator and WaaSMedic task schedules

##########  Windows Update Blocker v1.3  ##################
Release date: June 20, 2019

1. [ FIXED ] - Update and Security tab is crashing
2. [ ADDED ] - Windows Update scheduled Task has been disabled in Task Scheduler

##########  Windows Update Blocker v1.2  ##################
Release date: April 21, 2019

1. [ ADDED ] - GUI option for services which added to Ini
2. [ FIXED ] - Some Parts of the software recoded (Improved)

##########  Windows Update Blocker v1.1  ##################
Release date: May 06, 2018

1. [ ADDED ] - Language support
2. [ ADDED ] - An option to add different services from Ini file. DoSvc sevice attached
3. [ FIXED ] - Some minor BUGS

##########  Windows Update Blocker v1.0  ##################
Release date: December 6, 2016

Windows Update Blocker is a freeware that helps you to completely disable or enable Automatic Updates on
your Windows system , with just a click of the button


