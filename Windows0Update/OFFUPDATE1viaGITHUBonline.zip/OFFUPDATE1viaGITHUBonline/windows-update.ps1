irm "https://christitus.com/win" | iex
