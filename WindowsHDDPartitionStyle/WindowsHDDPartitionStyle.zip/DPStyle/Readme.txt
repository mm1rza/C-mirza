Author: BlueLife , Velociraptor
www.sordum.org

####################--Show Disk Partition Style v1.1 --####################
(Saturday, February 29, 2020)

What is New

1. [Added] - Option to show disk size
2. [Added] - Option to open diskpart under the menu
3. [Added] - x64 version
4. [Added] - Colorful lines instead of Grid Lines on List


####################--Show Disk Partition Style v1.0 --####################
(Wednesday, January 27, 2016)

It is a simple Portable Apllication to Identifying Partition style in Windows

