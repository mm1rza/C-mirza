1. Install app

2. Copy " NSM.LIC " into :

	For 32-bit : C:\Program Files\NetSupport\NetSupport School
	For 64-bit : C:\Program Files (x86)\NetSupport\NetSupport School

3. Done.

 # NOTE #

if you have information during installation: "the trial license is too old to use." -> change the date to any of 2020
