// ==UserScript==
// @name        All Popups Blocker and reCAPTCHA Solver
// @namespace   Violentmonkey Scripts
// @include     /^(https?:\/\/)(.+)?(shortzon|coinadfly|bclikeqt|fc-lc)(\.com)(\/.*)/
// @include     /^(https?:\/\/)(.+)?(downfile|promo-visits)(\.site)(\/.*)/
// @include     /^(https?:\/\/)(.+)?(bcvc|satoshi-win)(\.xyz)(\/.*)/
// @include     /^(https?:\/\/)(1dogecoin|faucet)(\.work)(\/.*)/
// @match       *://linkvertise.download/download/*
// @match       *://*.trangchu.news/*
// @match       *://*.bitcoinly.in/*
// @match       *://*.vshort.link/*
// @match       *://*.linka.click/*
// @match       *://*.linkres.in/*
// @match       *://*.cashurl.in/*
// @match       *://*.linkad.in/*
// @match       *://*.cuturl.in/*
// @match       *://*.mitly.us/*
// @match       *://*.aii.sh/*
// @match       *://*.iir.ai/*
// @match       *://*/recaptcha/*
// @version     4.1
// @author      Blogger Pemula
// @run-at      document-start
// @license     GPL-3.0-or-later
// @grant       GM_xmlhttpRequest
// @require     https://code.jquery.com/jquery-3.6.0.min.js
// @require     https://greasyfork.org/scripts/444872-7-recaptcha-solver-backup/code/7_Recaptcha%20Solver%20(BackUp).user.js#bypass=true
// @require     https://cdn.jsdelivr.net/npm/notify-js-legacy@0.4.1/notify.js
// @description This Script will Block All Popups Sites in the Lists , and Auto Solving Google reCAPTCHA
// ==/UserScript==
/*jslint evil: true */
function redirect(url, blog = true) {location = blog ? 'https://rotator.nurul-huda.sch.id/?url=' + url : url;}
var blockonclick = new Function("console.log('Blocked By BloggerPemula')");

function BlockPopup(e){return 1;}
parent.open=BlockPopup; this.open=BlockPopup; window.open=BlockPopup; onload=BlockPopup;
window.open = function(){ return;};
onload = function(){ return;};
this.open = function(){ return;};
parent.open = function(){ return;};
unsafeWindow.open = function(){};
if(['linkvertise.download'].includes(window.location.hostname) > -1){let $=window.jQuery,lokal=!0;function BypassLinkver(){let e=window.location;"/"!=e.pathname&&"text/html"==document.contentType&&bypass(e)}async function bypass(e){if(!("linkvertise.com"==e.hostname&&e.pathname.startsWith("/")&&e.pathname.split("/").length>=3))return"linkvertise.download"==e.hostname?void bypassDownload(e):void 0;if(lokal){$.notify("Steps 1...",{className:"info",autoHideDelay:7e3});let t=e.pathname.split("/")[1],n=e.pathname.split("/")[2],a=e.pathname.includes("/dynamic"),s=a&&window.location.search.includes("&r=")?window.location.search.split("&r=")[1].split("&")[0]:a&&window.location.search.includes("?r=")?window.location.search.split("?r=")[1].split("&")[0]:"";GM_xmlhttpRequest({method:"GET",url:"https://publisher.linkvertise.com/api/v1/redirect/link/"+(a?"dynamic/"+t+"/"+s:"static/"+t+"/"+n),onload:function(a){let s=JSON.parse(a.responseText);n=s.data.link.url;let o=s.data.link.target_type;GM_xmlhttpRequest({method:"GET",url:"https://balatin.de/api/serial?p="+n+"&pid="+t+"&id="+s.data.link.id,onload:function(a){let i=JSON.parse(a.responseText);GM_xmlhttpRequest({method:"GET",url:"https://paper.ostrichesica.com/ct?id=14473&url="+encodeURIComponent(e.href),onload:function(e){let a=e.responseText.split('"jsonp":"')[1].split('"')[0];GM_xmlhttpRequest({method:"POST",url:"https://publisher.linkvertise.com/api/v1/redirect/link/"+t+"/"+n+"/traffic-validation",data:JSON.stringify({type:"cq",token:a}),headers:{"Content-Type":"application/json"},onload:function(e){s=JSON.parse(e.responseText);let a=s.data.tokens.TARGET;i.token=a;GM_xmlhttpRequest({method:"POST",url:"https://publisher.linkvertise.com/api/v1/redirect/link/"+t+"/"+n+("PASTE"==o?"/paste":"/target"),data:JSON.stringify(i),headers:{"Content-Type":"application/json"},onload:function(e){if((s=JSON.parse(e.responseText),"PASTE"!=o)){let e=new URL(s.data.target);"linkvertise.download"==e.hostname?bypassDownload(e):LinkRes(e.href)}else LinkRes("https://balatin.de/api/txt/"+btoa(unescape(encodeURIComponent(s.data.paste))))}})}})}})}})}})}else GM_xmlhttpRequest({method:"POST",url:"https://api.bypass.vip/",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8"},data:"url="+encodeURIComponent(e.href),onload:function(e){let t=JSON.parse(e.responseText);null!=t&&null!=t.destination?LinkRes(t.destination):null!=t&&null!=t.response?LinkRes("https://balatin.de/api/txt/"+btoa(unescape(encodeURIComponent(t.response)))):$.notify("Could not bypass link",{className:"error",autoHideDelay:1e4})}})}BypassLinkver();const Step3=!0;async function bypassDownload(e){if(e.pathname.startsWith("/download/")){let t=e.pathname.split("/")[2],n=e.pathname.split("/")[3];$.notify("Steps 2..",{className:"base",autoHideDelay:3e3});let a=JSON.stringify({key:e.pathname.split("/")[4]});GM_xmlhttpRequest({method:"POST",url:"https://publisher.linkvertise.com/api/v1/redirect/link/"+t+"/"+n+"/download-info",data:a,headers:{"Content-Type":"application/json"},onload:function(e){let t=JSON.parse(e.responseText),n=new URL(t.data.downloadUrl);n.hostname.endsWith("cloudfront.net")?GM_xmlhttpRequest({method:"GET",url:"https://balatin.de/api/stage6?url="+n.href,onload:function(e){t=e.responseText;let n=JSON.stringify({a:"Linkvertise",s:"Linkvertise",u:t});GM_xmlhttpRequest({method:"POST",url:"https://d17kz3i6hbr7d3.cloudfront.net/o",data:n,headers:{"Content-Type":"application/json"},onload:function(e){LinkRes(JSON.parse(e.responseText).i.cu)}})}}):LinkRes(n.href)}})}}const rest=10,newtab=!1;async function LinkRes(e){try{new URL(e);}catch(e){return void(lokal&&bypass(window.location))}window.location.pathname.startsWith("/48193/")?setTimeout((()=>{$.notify("Redirecting...",{className:"success",autoHideDelay:8e3});redirect(e);}),15100):setTimeout((()=>{$.notify("Redirecting...",{className:"success",autoHideDelay:8e3});redirect(e);}),10)}}else {}